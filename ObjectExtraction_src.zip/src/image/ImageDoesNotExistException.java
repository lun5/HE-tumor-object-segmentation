package image;

public class ImageDoesNotExistException extends Exception {

}
