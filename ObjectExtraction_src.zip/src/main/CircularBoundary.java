package main;

public class CircularBoundary {

	int [] x;
	int [] y;
	int N, r;
	
	public CircularBoundary(){
		
	}

	public int getN() {
		return N;
	}

	public void setN(int n) {
		N = n;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int[] getX() {
		return x;
	}

	public void setX(int[] x) {
		this.x = x;
	}

	public int[] getY() {
		return y;
	}

	public void setY(int[] y) {
		this.y = y;
	}
	
	
}
